<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/confirmar_borrar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300&display=swap" rel="stylesheet">
    <title>Planillas</title>
</head>
<body>
    <div class="displayCenter">
        <table>
            <tr>
                <td>Lote</td>
                <td>Fecha</td>
                <td>cuna</td>
            </tr>
            <tr>
                <td><?php echo e($registro->lote); ?></td>
                <td><?php echo e($registro->fecha); ?></td>
                <td><?php echo e($registro->cuna); ?></td>
            </tr>
        </table>
    
        <form action="<?php echo e(url('insert_name')); ?>" class="displayCenter">
            <label for="nombre">Nombre</label>
            <input type="search" id="buscador" autocomplete="off">  
            <div class="overflowShort displayCenter">
                <?php $__currentLoopData = $registrosPersonal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registroPersonal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="option" data-value="<?php echo e($registroPersonal->nombre_completo); ?>">
                        <input type="radio" name="nombre" value="<?php echo e($registroPersonal->nombre_completo); ?>">
                        <label><?php echo e($registroPersonal->nombre_completo); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <input type="hidden" name="id" value="<?php echo e($registro->id); ?>">
            <input type="submit" value="Enviar">
        </form>
    </div>
    <script>
        const $buscador = document.getElementById("buscador"),
        $opciones = document.querySelectorAll(".option")

        if($buscador != null){
        $buscador.addEventListener("keyup", e=>{
            $opciones.forEach(el=>{
                (el.dataset.value.toLowerCase().indexOf(e.target.value.toLowerCase()) == -1) ? el.classList.add("invisible") : el.classList.remove("invisible");
            })
        });
        }
    </script>
</body>
</html><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/insertar_nombre.blade.php ENDPATH**/ ?>