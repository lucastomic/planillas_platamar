
    
<?php $__env->startSection('title'); ?>
    <h1>Planillas de corte</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tabla'); ?>
    <div class="overflow">
        <table>
            <tr>
                <th>Lote</th>
                <th>Fecha</th>
                <th>Nombre</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($registro->lote); ?></td>
                    <td><?php echo e($registro->fecha); ?></td>
                    <td><?php echo e($registro->nombre); ?></td>
                    <td><?php echo e($registro->elemento1); ?></td>
                    <td><?php echo e($registro->elemento2); ?></td>
                    <td><?php echo e($registro->elemento3); ?></td>
                    <td><?php echo e($registro->elemento4); ?></td>
                    <td><?php echo e($registro->elemento5); ?></td>
                    <td><button><a href="<?php echo e(url("/confirmar_borrar/{$registro->id}/{$registro->table}")); ?>">Eliminar</a></button></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3">Aún no hay registros subidos acerca de esta planilla.<td></tr>
            <?php endif; ?>
        </table>
    </div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
    <input type="hidden" name="seccion" value="corte">
    
    <label for="nombre">Nombre</label>
    <input type="search" id="buscador" autocomplete="off">  
    <div class="overflowShort displayCenter">
        <?php $__currentLoopData = $registrosPersonal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="option" data-value="<?php echo e($registro->nombre_completo); ?>">
            <input type="radio" name="nombre" value="<?php echo e($registro->nombre_completo); ?>">
            <label><?php echo e($registro->nombre_completo); ?></label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <label>Pesos</label>   
    <input type="number" autocomplete="off" step="0.01" name="elemento1">
    <input type="number" autocomplete="off" step="0.01" name="elemento2">
    <input type="number" autocomplete="off" step="0.01" name="elemento3">
    <input type="number" autocomplete="off" step="0.01" name="elemento4">
    <input type="number" autocomplete="off" step="0.01" name="elemento5">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('produccion.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/produccion/corte.blade.php ENDPATH**/ ?>