<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/horario.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300&display=swap" rel="stylesheet">
    <title>Planillas</title>
</head>
<body>
<button><a href="<?php echo e((session('logged') == 'produccion') ? url('/menu_produccion') : url('/menu_insumos')); ?>">Volver al menu</a></button>
    <h1>Planillas de horario</h1>
    <div class="overflow">
    <table>
        <tr>
            <th>Fecha</th>
            <th>Nombre</th>
            <th>Entrada</th>
            <th>Salida</th>
            <th>Total</th>
            <th>Categoría</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($registro->fecha); ?></td>
                <td><?php echo e($registro->nombre); ?></td>
                <td><?php echo e($registro->entrada); ?></td>
                <td><?php echo e($registro->salida); ?></td>
                <td><?php echo e($registro->total); ?></td>
                <td><?php echo e($registro->categoria); ?></td>
                <td><button><a href="<?php echo e(url("/insertar_salida/{$registro->id}")); ?>">Insertar salida</a></button></td>
                <td><button><a href="<?php echo e(url("/confirmar_borrar/{$registro->id}/{$registro->table}")); ?>">Eliminar</a></button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6">Aún no hay registros subidos acerca de esta planilla.<td></tr>
        <?php endif; ?>
    </table>
    </div>
    <form action="<?php echo e(url('create_horario')); ?>" class="displayCenter">
        
        <label for="nombre">Nombre</label>
        <input type="search" id="buscador" autocomplete="off">  
        <div class="overflowShort displayCenter">
            <?php $__currentLoopData = $registrosPersonal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="option" data-value="<?php echo e($registro->nombre_completo); ?>">
                <input type="radio" name="nombre" value="<?php echo e($registro->nombre_completo); ?>">
                <label><?php echo e($registro->nombre_completo); ?></label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <label for="fecha">Fecha</label>
        <input type="date" value="<?php echo e($fecha); ?>" name="fecha" required>

        <label for="entrada">Entrada</label>
        <input type="time" name="entrada" required>

        <label for="salida">Salida</label>
        <input type="time" name="salida">

        <label for="categoria">Categoría</label>
        <select name="categoria" required>
            <option value="Encargado">Encargado</option>
            <option value="Peón">Peón</option>
            <option value="Ayudante">Ayudante</option>
            <option value="Barrilero">Barrilero</option>
        </select>

        <input type="submit" value="Enviar">

    </form>
</body>
</html><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/horario/horario.blade.php ENDPATH**/ ?>