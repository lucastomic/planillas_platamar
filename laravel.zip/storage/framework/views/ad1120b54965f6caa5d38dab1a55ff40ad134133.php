<?php
    // if(!session('logged')){
    //     return redirect()->route('login');
    // }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Planillas de:</h1>
    <ul>
        <li><a href="<?php echo e(url('/corte')); ?>">Corte</a></li>
        <li><a href="<?php echo e(url('/envase')); ?>">Envase</a></li>
        <li><a href="<?php echo e(url('/filet')); ?>">Filet</a></li>
        <li><a href="<?php echo e(url('/secado')); ?>">Secado</a></li>
        <li><a href="<?php echo e(url('/descabezado')); ?>">Descabezado</a></li>
    </ul>
</body>
</html><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/menu.blade.php ENDPATH**/ ?>