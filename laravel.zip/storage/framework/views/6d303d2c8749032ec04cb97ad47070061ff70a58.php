
    
<?php $__env->startSection('title'); ?>
    <h1>Planillas de descabezado</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tabla'); ?>
    <table>
        <tr>
            <th>Lote</th>
            <th>Fecha</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Valor</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($registro->lote); ?></td>
                <td><?php echo e($registro->fecha); ?></td>
                <td><?php echo e($registro->nombre); ?></td>
                <td><?php echo e($registro->producto); ?></td>
                <td><?php echo e($registro->elemento1); ?></td>
                <td><button><a href="<?php echo e(url("/confirmar_borrar/{$registro->id}")); ?>">Eliminar</a></button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Aún no hay registros subidos acerca de esta planilla.</p>
        <?php endif; ?>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
    <input type="hidden" name="seccion" value="descabezado">
    
    <label for="nombre">Nombre</label>
    <input type="text" name="nombre">

    <label for="producto">Tipo</label>   

    <select name="producto">
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e($produccionController::get_prod($producto, $productoD)); ?> value="<?php echo e($producto); ?>"><?php echo e($producto); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="elemento1">Peso</label>
    <input type="number" step="0.01" name="elemento1">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('planillas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/planillas/descabezado.blade.php ENDPATH**/ ?>