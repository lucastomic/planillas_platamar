
    
<?php $__env->startSection('title'); ?>
    <h1>Planillas de corte</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tabla'); ?>
    <table>
        <tr>
            <th>Lote</th>
            <th>Fecha</th>
            <th>Pesada camión</th>
            <th>Total cajones</th>
            <th>Cajón</th>
            <th>Temperatura</th>
            <th>Peso bruto</th>
            <th>Fauna acomp</th>
            <th>Peso neto</th>
            <th>Piezas x2 kg</th>
            <th>Histamina</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($registro->lote); ?></td>
                <td><?php echo e($registro->fecha); ?></td>
                <td><?php echo e($registro->pesada_camion); ?></td>
                <td><?php echo e($registro->total_cajones); ?></td>
                <td><?php echo e($registro->cajon); ?></td>
                <td><?php echo e($registro->temperatura); ?></td>
                <td><?php echo e($registro->peso_bruto); ?></td>
                <td><?php echo e($registro->fauna_acomp); ?></td>
                <td><?php echo e($registro->peso_neto); ?></td>
                <td><?php echo e($registro->piezasx2kg); ?></td>
                <td><?php echo e($registro->histamina); ?></td>
                <td><button><a href="<?php echo e(url("/confirmar_borrar/{$registro->id}")); ?>">Eliminar</a></button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Aún no hay registros subidos acerca de esta planilla.</p>
        <?php endif; ?>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
    <input type="hidden" name="seccion" value="ingreso">
    
    <label for="nombre">Nombre</label>
    <input type="text" name="nombre">

    <label for="pesada_camion">Pesada camion</label>   
    <input type="number" step="0.01" name="pesada_camion">
    <label for="total_cajones">Total cajones</label>
    <input type="number" step="0.01" name="total_cajones">
    <label for="cajon">Cajon</label>
    <input type="number" step="0.01" name="cajon">
    <label for="temperatura">Temperatura</label>
    <input type="number" step="0.01" name="temperatura">
    <label for="peso_bruto">Peso bruto</label>
    <input type="number" step="0.01" name="peso_bruto">
    <label for="fauna_acomp">Fauna acomp</label>
    <input type="text" name="fauna_acomp">
    <label for="peso_neto">Peso neto</label>
    <input type="number" step="0.01" name="peso_neto">
    <label for="piezasx2kg">Piezas x2kg</label>
    <input type="number" step="0.01" name="piezasx2kg">
    <label for="histamina">Histamina</label>
    <input type="number" step="0.01" name="histamina">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('planillas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/planillas/ingreso.blade.php ENDPATH**/ ?>