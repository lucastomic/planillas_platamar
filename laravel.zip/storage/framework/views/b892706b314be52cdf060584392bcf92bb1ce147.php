<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/confirmar_borrar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300&display=swap" rel="stylesheet">
    <title>Planillas</title>
</head>
<body>
    <h1>¿Estás seguro/a de borrar el siguiente registro?</h1>
<div class="displayCenter">

    <table>
        <?php if($registro->table == "produccion"): ?>
            <tr>
                <td>Nombre</td>
                <td>Lote</td>
                <td>Fecha</td>
            </tr>
            <tr>
                <td><?php echo e($registro->nombre); ?></td>
                <td><?php echo e($registro->lote); ?></td>
                <td><?php echo e($registro->fecha); ?></td>
            </tr>
        <?php elseif($registro->table == "insumos"): ?>
            <?php if($registro->seccion == "varios"): ?>
                <tr>
                    <td>Fecha</td>
                    <td>Producto</td>
                    <td>Insumo</td>
                </tr>
                <tr>
                    <td><?php echo e($registro->fecha); ?></td>
                    <td><?php echo e($registro->producto); ?></td>
                    <td><?php echo e($registro->insumo); ?></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td>Origen</td>
                    <td>Lote</td>
                    <td>Fecha</td>
                </tr>
                <tr>
                    <td><?php echo e($registro->origen); ?></td>
                    <td><?php echo e($registro->lote); ?></td>
                    <td><?php echo e($registro->fecha); ?></td>
                </tr>
            <?php endif; ?>
        <?php elseif($registro->table == "horarios"): ?>
            <tr>
                <td>Nombre</td>
                <td>Fecha</td>
                <td>Categoria</td>
            </tr>
            <tr>
                <td><?php echo e($registro->nombre); ?></td>
                <td><?php echo e($registro->fecha); ?></td>
                <td><?php echo e($registro->categoria); ?></td>
            </tr>
        <?php elseif($registro->table == "resumen"): ?>
            <tr>
                <td>Fecha</td>
                <td>Lote</td>
            </tr>
            <tr>
                <td><?php echo e($registro->fecha); ?></td>
                <td><?php echo e($registro->lote); ?></td>
            </tr>
        <?php elseif($registro->table == "personal"): ?>
            <tr>
                <td>Nombre</td>
                <td>DNI</td>
                <td>Categoría</td>
            </tr>
            <tr>
                <td><?php echo e($registro->nombre_completo); ?></td>
                <td><?php echo e($registro->dni); ?></td>
                <td><?php echo e($registro->categoria); ?></td>
            </tr>
        <?php endif; ?>
        <tr>
            <td>
                <?php if($registro->table === "produccion"): ?>
                    <form method="POST" action="<?php echo e(url("borrar_produccion/{$registro->id}")); ?>">
                <?php elseif($registro->table === "insumos"): ?>
                    <form method="POST" action=" <?php echo e(url("borrar_insumo/{$registro->id}")); ?>">
                <?php elseif($registro->table === "horarios"): ?>
                    <form method="POST" action="<?php echo e(url("borrar_horario/{$registro->id}")); ?>">
                <?php elseif($registro->table === "resumen"): ?>
                    <form method="POST" action="<?php echo e(url("borrar_resumen/{$registro->id}")); ?>">
                <?php elseif($registro->table === "personal"): ?>
                    <form method="POST" action="<?php echo e(url("borrar_personal/{$registro->id}")); ?>">
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                    <button type="submit">Sí</button>
                </form>
            </td>
            <td></td>
            <td>
                <button><a href='<?php echo e(URL::previous()); ?>'>No</a></button>
            </td>
        </tr>
    </table>
</div>
</body>
</html><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/confirmar_borrar.blade.php ENDPATH**/ ?>