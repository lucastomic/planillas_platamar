
    
<?php $__env->startSection('title'); ?>
    <h1>Planillas de varios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tabla'); ?>
    <div class="overflow">
    <table>
        <tr>
            <th>Fecha</th>
            <th>Producto</th>
            <th>Insumo</th>
            <th>Cantidad</th>
            <th>Cantidad por bulto</th>
            <th>Total</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($registro->fecha); ?></td>
                <td><?php echo e($registro->producto); ?></td>
                <td><?php echo e($registro->insumo); ?></td>
                <td><?php echo e($registro->cantidad); ?></td>
                <td><?php echo e($registro->cantidadPorBulto); ?></td>
                <td><?php echo e($registro->total); ?></td>
                <td><button><a href="<?php echo e(url("/confirmar_borrar/{$registro->id}/{$registro->table}")); ?>">Eliminar</a></button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6">Aún no hay registros subidos acerca de esta planilla.<td></tr>
        <?php endif; ?>
    </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
    <input type="hidden" name="seccion" value="varios">

    <label for="producto">Producto</label>
    <select name="producto">
        <option value="Anchoero 90">Anchoero 90</option>
        <option value="Morronero 90">Morronero 200</option>
        <option value="Estrella 660 ">Estrella 660</option>
        <option value="PET">PET</option>
        <option value="General">General</option>
    </select>

    <label for="producto">Producto</label>
    <select name="insumo">
        <option value="Caja">Caja</option>
        <option value="Frasco">Frasco</option>
        <option value="Tapa">Tapa</option>
        <option value="Aceite">Aceite</option>
        <option value="Folex">Folex</option>
        <option value="Sal">Sal</option>
    </select>

    <label for="cantidad">Cantidad</label>
    <input type="number" autocomplete="off" name="cantidad">

    <label for="cantidadPorBulto">Cantidad por bulto</label>
    <input type="number" autocomplete="off" step="0.01" name="cantidadPorBulto">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('insumos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/insumos/varios.blade.php ENDPATH**/ ?>