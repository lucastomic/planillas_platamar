<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/insertar_salida.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300&display=swap" rel="stylesheet">
    <title>Planillas</title>
</head>
<body>
    <div class="displayCenter">
        <table>
            <tr>
                <td>Nombre</td>
                <td>Fecha</td>
            </tr>
            <tr>
                <td><?php echo e($registro->nombre); ?></td>
                <td><?php echo e($registro->fecha); ?></td>
            </tr>
        </table>
    
        <form action="<?php echo e(url('insert_salida')); ?>" class="displayCenter">
            <label for="salida">Salida</label>
            <input type="time" name="salida">
            <input type="hidden" name="id" value="<?php echo e($registro->id); ?>">
            <input type="submit" value="Enviar">
        </form>
    </div>
</body>
</html><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/horario/insertar_salida.blade.php ENDPATH**/ ?>