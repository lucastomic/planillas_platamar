
    
<?php $__env->startSection('title'); ?>
    <h1>Planillas de pescado</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tabla'); ?>
    <div class="overflow">

        <table>
            <tr>
                <th>Lote</th>
                <th>Nº remito</th>
                <th>Fecha</th>
                <th>Pesada camión</th>
                <th>Total cajones</th>
                <th>Cajón</th>
                <th>Temperatura</th>
                <th>Peso bruto</th>
                <th>Observaciones</th>
                <th>Bachazas</th>
                <th>Peso neto</th>
                <th>Piezas x2 kg</th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($registro->lote); ?></td>
                    <td><?php echo e($registro->nro_remito); ?></td>
                    <td><?php echo e($registro->fecha); ?></td>
                    <td><?php echo e($registro->pesada_camion); ?></td>
                    <td><?php echo e($registro->total_cajones); ?></td>
                    <td><?php echo e($registro->cajon); ?></td>
                    <td><?php echo e($registro->temperatura); ?></td>
                    <td><?php echo e($registro->peso_bruto); ?></td>
                    <td><?php echo e($registro->observaciones); ?></td>
                    <td><?php echo e($registro->bachazas); ?></td>
                    <td><?php echo e($registro->peso_neto); ?></td>
                    <td><?php echo e($registro->piezasx2kg); ?></td>
                    <td><button><a href="<?php echo e(url("/confirmar_borrar/{$registro->id}/{$registro->table}")); ?>">Eliminar</a></button></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="11">Aún no hay registros subidos acerca de esta planilla.<td></tr>
            <?php endif; ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
    <input type="hidden" name="seccion" value="pescado">
    
    <label for="lote">Lote</label>
    <input type="text" name="lote" autocomplete="off" value="<?php echo e($lote); ?>" required>

    <label for="nro_remito">Nº Remito</label>
    <input type="number" name="nro_remito">
    <label for="origen">Origen</label>
    <input type="text" name="origen">
    <label for="pesada_camion">Pesada camion</label>   
    <input type="number" autocomplete="off" step="0.01" name="pesada_camion">
    <label for="total_cajones">Total cajones</label>
    <input type="number" autocomplete="off" step="0.01" name="total_cajones">
    <label for="cajon">Cajon</label>
    <input type="number" autocomplete="off" step="0.01" name="cajon">
    <label for="temperatura">Temperatura</label>
    <input type="number" autocomplete="off" step="0.01" name="temperatura">
    <label for="peso_bruto">Peso bruto</label>
    <input type="number" autocomplete="off" step="0.01" name="peso_bruto">
    <label for="observaciones">Observaciones</label>
    <input type="text" name="observaciones">
    <label for="bachazas">Bachazas</label>
    <input type="number" step="0.01" name="bachazas">
    <label for="peso_neto">Peso neto</label>
    <input type="number" autocomplete="off" step="0.01" name="peso_neto">
    <label for="piezasx2kg">Piezas x2kg</label>
    <input type="number" autocomplete="off" step="0.01" name="piezasx2kg">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('insumos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/insumos/pescado.blade.php ENDPATH**/ ?>