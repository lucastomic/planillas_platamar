
    
<?php $__env->startSection('title'); ?>
    <h1>Planillas de secado</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tabla'); ?>
    <table>
        <tr>
            <th>Lote</th>
            <th>Fecha</th>
            <th>Nombre</th>
            <th>Kg</th>
            <th>Cuna</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($registro->lote); ?></td>
                <td><?php echo e($registro->fecha); ?></td>
                <td><?php echo e($registro->nombre); ?></td>
                <td><?php echo e($registro->elemento1); ?></td>
                <td><?php echo e($registro->cuna); ?></td>

                <td><button><a href="<?php echo e(url("/confirmar_borrar/{$registro->id}")); ?>">Eliminar</a></button></td>
                <td><button><a href="<?php echo e(url("/insertar_nombre/{$registro->id}")); ?>">Insertar nombre</a></button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>Aún no hay registros subidos acerca de esta planilla.</p>
        <?php endif; ?>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('form'); ?>
    <input type="hidden" name="seccion" value="secado">

    <label>Cuna</label>   
    <input type="number" step="0.01" name="cuna">    
    
    <label>Kg cuna</label>   
    <input type="number" step="0.01" name="elemento1">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('planillas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/planillas/secado.blade.php ENDPATH**/ ?>