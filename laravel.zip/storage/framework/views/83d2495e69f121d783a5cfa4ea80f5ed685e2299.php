<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/menu_produccion.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/general.css')); ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@300&display=swap" rel="stylesheet">
    <title>Planillas</title>
</head>
<body>
    <div class="displayCenter">
        <h1>Planillas de:</h1>
        <ul class="displayCenter">
            <li><a href="<?php echo e(url('/corte')); ?>">Corte</a></li>
            <li><a href="<?php echo e(url('/envase')); ?>">Envase</a></li>
            <li><a href="<?php echo e(url('/filet')); ?>">Filet</a></li>
            <li><a href="<?php echo e(url('/secado')); ?>">Secado</a></li>
            <li><a href="<?php echo e(url('/descabezado')); ?>">Descabezado</a></li>
            <li><a href="<?php echo e(url('/horario')); ?>">Horario</a></li>
        </ul>
    </div>
</body>
</html><?php /**PATH C:\Users\ltomi\laragon\www\planillas_platamar_2.0\resources\views/produccion/menu_produccion.blade.php ENDPATH**/ ?>